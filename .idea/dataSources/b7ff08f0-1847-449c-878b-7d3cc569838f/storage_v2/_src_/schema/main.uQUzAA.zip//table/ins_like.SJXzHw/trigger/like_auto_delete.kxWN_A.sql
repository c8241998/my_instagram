CREATE TRIGGER like_auto_delete
  AFTER DELETE
  ON ins_like
BEGIN

  UPDATE ins_post
  SET likes = likes - 1
  where id = old.post_id;

END;

