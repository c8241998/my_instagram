CREATE TRIGGER post_auto_delete
  AFTER DELETE
  ON ins_post
BEGIN

  UPDATE ins_userprofile
  SET posts = posts - 1
  where id = old.user_id;

END;

