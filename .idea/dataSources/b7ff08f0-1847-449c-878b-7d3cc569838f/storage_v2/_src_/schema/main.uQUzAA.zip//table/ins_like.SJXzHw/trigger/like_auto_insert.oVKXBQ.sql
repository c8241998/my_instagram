CREATE TRIGGER like_auto_insert
  AFTER INSERT
  ON ins_like
BEGIN

  UPDATE ins_post
  SET likes = likes + 1
  where id = new.post_id;

END;

